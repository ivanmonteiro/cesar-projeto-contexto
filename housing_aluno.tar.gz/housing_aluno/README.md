# install
install python3 and pip

## install the libraries:

```bash
pip install numpy
pip install pandas
pip install matplotlib
pip install scikit-learn
pip install scipy
pip install jupyter
```

# open the document
```bash
jupyter notebook housing.ipynb
```